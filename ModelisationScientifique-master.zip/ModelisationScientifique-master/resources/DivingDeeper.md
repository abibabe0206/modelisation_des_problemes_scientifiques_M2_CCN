# Links to more resources

## French MOOC on Python
https://www.youtube.com/channel/UCWpkVtH93qQ5JpSZEwONjGA

## Joel Grus @JupyterCon 2018
https://www.youtube.com/watch?v=7jiPeIFXb6U

## Further reading
- [The Hitchhiker’s Guide to Python!](https://docs.python-guide.org/)
- [Magic methods](https://www.python-course.eu/python3_magic_methods.php)

### OOP
 - [OpenClassRoom Python Tutorial](https://openclassrooms.com/fr/courses/235344-apprenez-a-programmer-en-python/232721-apprehendez-les-classes)

# ModelisationScientifique
Teaching resources for the scientific modelling course.

# Links of the slides

## Overview of the module
>> https://tinyurl.com/SciModelling

## Challenges of Scientific modelling

>> https://github.com/Jnsll/ModelisationScientifique/blob/master/slides/Challenges%20of%20SciModelling.pdf
